#!/bin/bash
#===============================================================================
#
#          FILE:  bat.sh
# 
#         USAGE:  ./bat.sh 
# 
#   DESCRIPTION:  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR:  Yan Wu (), teloon198888@gmail.com
#       COMPANY:  S.J.T.U.
#       VERSION:  1.0
#       CREATED:  08/03/2009 12:05:06 PM CST
#      REVISION:  ---
#===============================================================================

make clear
make

